<?php
/**
 * Plugin Name: Orca Landing Pages (GitHub)
 * Plugin URI:  https://github.com/orcatribeltd-glitch/orca-landing-pages
 * Description: מציג דפי נחיתה ישירות מריפו GitHub ([landing_page name="…"]), ויוצר עמודים חדשים כטיוטה לפי pages.json בריפו, וממיר עמודי אלמנטור קיימים ל-HTML עם גיבוי כתבנית. כל push מתעדכן באתר, בלי FTP.
 * Version:     1.13.1
 * Author:      Orca Tribe
 * Text Domain: orca-landing-pages
 */

if (!defined('ABSPATH')) {
    exit;
}

final class Orca_Landing_Pages
{
    const OPTION      = 'olp_settings';
    const CACHE_PFX   = 'olp_page_';
    const STALE_PFX   = 'olp_stale_';
    const VERSION     = '1.13.1';
    const FOOTER_MAX_CHARS = 1500; // a footer is a few lines; a legal document is thousands of characters
    const PAGE_CACHE_SECONDS = 60;
    const GEN_OPTION  = 'olp_cache_generation';
    const REF_OPTION  = 'olp_git_ref';   // commit SHA from the last push webhook, else the branch
    const BLOG_OPTION = 'olp_blog';      // sites.json "blog": which repo pages dress the posts and the blog index

    /** 'post' or 'index' while blog-template.php is rendering, else '' */
    public static $blog_mode = '';

    public static function defaults(): array
    {
        return [
            'repo'           => 'orcatribeltd-glitch/orca-landing-pages',
            'branch'         => 'main',
            'token'          => '',
            'ttl'            => 300,
            'webhook_secret' => '',
            'cpanel_host'    => '',
            'cpanel_user'    => '',
            'cpanel_token'   => '',
        ];
    }

    public static function settings(): array
    {
        $saved = get_option(self::OPTION, []);
        if (!is_array($saved)) {
            $saved = [];
        }
        $s = array_merge(self::defaults(), $saved);
        if (defined('OLP_GITHUB_TOKEN') && OLP_GITHUB_TOKEN) {
            $s['token'] = OLP_GITHUB_TOKEN;
        }
        $s['ttl'] = max(30, (int) $s['ttl']);
        return $s;
    }

    public static function boot(): void
    {
        add_shortcode('landing_page', [__CLASS__, 'shortcode']);
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_post_olp_purge', [__CLASS__, 'handle_purge']);
        add_action('rest_api_init', [__CLASS__, 'rest_routes']);
        add_action('send_headers', [__CLASS__, 'short_page_cache']);
        add_filter('pre_set_site_transient_update_plugins', [__CLASS__, 'inject_update']);
        add_filter('plugins_api', [__CLASS__, 'plugin_info'], 10, 3);
        add_action('wp_footer', [__CLASS__, 'privacy_link_script'], 99);
        add_filter('template_include', [__CLASS__, 'blog_template'], 99);
    }

    /* ---------- self-update from the repo ---------- */

    const UPDATE_CACHE = 'olp_remote_version';

    /** wordpress/version.json in the repo: {"version":"1.7.2","package":"https://…/orca-landing-pages-1.7.2.zip"} */
    public static function remote_version(bool $force = false): array
    {
        $cached = get_transient(self::UPDATE_CACHE);
        if (!$force && is_array($cached)) {
            return $cached;
        }
        $s   = self::settings();
        // at the pinned commit (set by the push webhook) the file is immutable, so the raw CDN can never hand back a stale version.json
        $url = sprintf('https://raw.githubusercontent.com/%s/%s/wordpress/version.json', trim($s['repo'], '/'), rawurlencode(self::git_ref()));
        $res = wp_remote_get($url, ['timeout' => 10, 'headers' => ['Cache-Control' => 'no-cache', 'User-Agent' => 'orca-landing-pages/' . self::VERSION]]);
        $info = [];
        if (!is_wp_error($res) && (int) wp_remote_retrieve_response_code($res) === 200) {
            $data = json_decode((string) wp_remote_retrieve_body($res), true);
            if (is_array($data) && !empty($data['version']) && !empty($data['package'])) {
                $info = ['version' => (string) $data['version'], 'package' => (string) $data['package']];
            }
        }
        set_transient(self::UPDATE_CACHE, $info, 6 * HOUR_IN_SECONDS);
        return $info;
    }

    public static function inject_update($transient)
    {
        if (!is_object($transient)) {
            return $transient;
        }
        $info = self::remote_version();
        if (!$info || version_compare($info['version'], self::VERSION, '<=')) {
            return $transient;
        }
        $basename = plugin_basename(__FILE__);
        $transient->response[$basename] = (object) [
            'slug'        => 'orca-landing-pages',
            'plugin'      => $basename,
            'new_version' => $info['version'],
            'package'     => $info['package'],
            'url'         => 'https://github.com/' . trim(self::settings()['repo'], '/'),
            'tested'      => get_bloginfo('version'),
        ];
        return $transient;
    }

    public static function plugin_info($result, $action, $args)
    {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== 'orca-landing-pages') {
            return $result;
        }
        $info = self::remote_version();
        return (object) [
            'name' => 'Orca Landing Pages (GitHub)', 'slug' => 'orca-landing-pages', 'version' => $info['version'] ?? self::VERSION,
            'author' => 'Orca Tribe', 'homepage' => 'https://github.com/' . trim(self::settings()['repo'], '/'),
            'download_link' => $info['package'] ?? '', 'sections' => ['description' => 'דפי נחיתה מריפו GitHub. עדכונים מגיעים מהריפו.'],
        ];
    }

    /**
     * Called from the webhook: if the repo says a newer plugin exists, install it
     * right now, so a push of a new version updates every site by itself.
     */
    public static function self_update(): string
    {
        delete_transient(self::UPDATE_CACHE);
        $info = self::remote_version(true);
        if (!$info || version_compare($info['version'], self::VERSION, '<=')) {
            return 'up to date (' . self::VERSION . ')';
        }
        if (!function_exists('get_filesystem_method')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if (get_filesystem_method() !== 'direct') {
            return 'newer ' . $info['version'] . ' available, filesystem not direct — update from the plugins screen';
        }
        // one upgrade at a time: a second refresh arriving mid-upgrade (GitHub's push hook and a manual
        // call, say) used to find the plugin folder half replaced and WordPress switched the plugin off
        if (get_transient('olp_self_update_lock')) {
            return 'newer ' . $info['version'] . ' available, an update is already running';
        }
        set_transient('olp_self_update_lock', gmdate('c'), 3 * MINUTE_IN_SECONDS);
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        delete_site_transient('update_plugins');
        wp_update_plugins();
        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader($skin);
        $basename = plugin_basename(__FILE__);
        $was_active = is_plugin_active($basename);
        $ok = $upgrader->upgrade($basename);
        if ($was_active && !is_plugin_active($basename)) {
            activate_plugin($basename);
        }
        delete_transient('olp_self_update_lock');
        $msg = ($ok === true ? 'updated to ' . $info['version'] : 'update failed: ' . implode(' | ', array_map('strval', (array) $skin->get_errors()->get_error_messages())));
        update_option('olp_last_self_update', gmdate('c') . ' ' . $msg, false);
        return $msg;
    }


    /* ---------- pages declared in the repo ---------- */

    /** The site's host without www, used to match `site` in pages.json. */
    public static function site_host(): string
    {
        $host = (string) wp_parse_url(home_url('/'), PHP_URL_HOST);
        return strtolower(preg_replace('/^www\./', '', $host));
    }

    /** Fetch a repo file at the pinned ref (any path, not only pages/). */
    public static function fetch_repo_file(string $path): string
    {
        $s    = self::settings();
        $url  = sprintf('https://raw.githubusercontent.com/%s/%s/%s', trim($s['repo'], '/'), rawurlencode(self::git_ref()), ltrim($path, '/'));
        $args = ['timeout' => 12, 'headers' => ['Cache-Control' => 'no-cache', 'User-Agent' => 'orca-landing-pages/' . self::VERSION]];
        if (!empty($s['token'])) {
            $args['headers']['Authorization'] = 'token ' . $s['token'];
        }
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res) || (int) wp_remote_retrieve_response_code($res) !== 200) {
            return '';
        }
        return (string) wp_remote_retrieve_body($res);
    }

    /**
     * pages.json at the repo root lists pages that should exist on a site:
     *   [{"site":"influence-club.co.il","name":"mashpian-cancel","slug":"cancel",
     *     "title":"משפיען בדיגיטל – ביטול מנוי","template":"templates/mashpian-cancel.json"}]
     * A page whose slug does not exist yet is created as a DRAFT from the
     * Elementor template (content + page settings). Existing pages are never
     * touched: what Jonathan edits in the editor (form recipient, publish)
     * stays his. Returns a list of what happened, also stored in an option.
     */
    public static function sync_pages(): array
    {
        $raw = self::fetch_repo_file('pages.json');
        $log = [];
        $list = $raw !== '' ? json_decode($raw, true) : null;
        if (!is_array($list)) {
            $log[] = 'pages.json: none';
            update_option('olp_last_sync', gmdate('c') . ' ' . implode('; ', $log), false);
            return $log;
        }
        $host = self::site_host();
        foreach ($list as $entry) {
            if (!is_array($entry) || empty($entry['site']) || empty($entry['slug']) || empty($entry['template'])) {
                continue;
            }
            if (strtolower(preg_replace('/^www\./', '', (string) $entry['site'])) !== $host) {
                continue;
            }
            $slug = sanitize_title((string) $entry['slug']);
            $existing = get_page_by_path($slug, OBJECT, 'page');
            if ($existing) {
                $log[] = $slug . ': exists (#' . $existing->ID . ')';
                continue;
            }
            $tpl = json_decode(self::fetch_repo_file((string) $entry['template']), true);
            if (!is_array($tpl) || empty($tpl['content']) || !is_array($tpl['content'])) {
                $log[] = $slug . ': template unreadable';
                continue;
            }
            $page_settings = isset($tpl['page_settings']) && is_array($tpl['page_settings']) ? $tpl['page_settings'] : [];
            $wp_template   = !empty($page_settings['template']) ? (string) $page_settings['template'] : 'elementor_canvas';
            unset($page_settings['template']);

            $post_id = wp_insert_post([
                'post_type'    => 'page',
                'post_status'  => 'draft',
                'post_title'   => (string) ($entry['title'] ?? $tpl['title'] ?? $slug),
                'post_name'    => $slug,
                'post_content' => '',
            ], true);
            if (is_wp_error($post_id) || !$post_id) {
                $log[] = $slug . ': insert failed';
                continue;
            }
            update_post_meta($post_id, '_elementor_edit_mode', 'builder');
            update_post_meta($post_id, '_elementor_template_type', 'wp-page');
            update_post_meta($post_id, '_elementor_data', wp_slash(wp_json_encode($tpl['content'], JSON_UNESCAPED_UNICODE)));
            update_post_meta($post_id, '_elementor_page_settings', $page_settings);
            update_post_meta($post_id, '_wp_page_template', $wp_template);
            if (defined('ELEMENTOR_VERSION')) {
                update_post_meta($post_id, '_elementor_version', ELEMENTOR_VERSION);
            }
            update_post_meta($post_id, '_olp_created_from', (string) $entry['template'] . '@' . self::git_ref());
            $log[] = $slug . ': created draft #' . $post_id;
        }
        update_option('olp_last_sync', gmdate('c') . ' ' . implode('; ', $log), false);
        return $log;
    }


    /* ---------- shared footer declared in the repo ---------- */

    private static function new_id(): string
    {
        return substr(md5(uniqid('', true)), 0, 7);
    }

    private static function footer_element(string $name): array
    {
        return [
            'id' => self::new_id(), 'elType' => 'container', 'isInner' => false,
            'settings' => ['content_width' => 'full', 'flex_direction' => 'column', '_olp_footer' => 'yes'],
            'elements' => [[
                'id' => self::new_id(), 'elType' => 'widget', 'widgetType' => 'shortcode', 'elements' => [],
                'settings' => ['shortcode' => '[landing_page name="' . $name . '"]'],
            ]],
        ];
    }

    /**
     * sites.json in the repo:
     *   {"influence-club.co.il": {"footer": {"name": "influence-footer",
     *      "replace_containing": ["אורקה טרייב בע״מ", "orcatribeltd@gmail.com"],
     *      "append_to_pages_created_from_repo": true}}}
     * For every page of this site: a TOP-LEVEL Elementor element whose content
     * contains one of the markers (the old hand-copied footer) is replaced by a
     * container with the footer shortcode. The original element is kept in
     * post meta _olp_footer_backup. Pages created from the repo that have no
     * footer get one appended. Nothing else in the page is touched.
     */
    /** Text of an element tree, lowercased, tags/entities/quotes/whitespace removed — for marker matching. */
    private static function element_text(array $el): string
    {
        $blob = (string) wp_json_encode($el, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $blob = html_entity_decode($blob, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $blob = preg_replace('/<[^>]+>/u', ' ', $blob);
        $blob = preg_replace('/[\x{05F4}\x{05F3}"\'“”‘’`\\\\]/u', '', $blob);
        $blob = preg_replace('/\s+/u', ' ', $blob);
        return function_exists('mb_strtolower') ? mb_strtolower($blob, 'UTF-8') : strtolower($blob);
    }

    private static function normalize_marker(string $m): string
    {
        $m = preg_replace('/[\x{05F4}\x{05F3}"\'“”‘’`\\\\]/u', '', $m);
        $m = preg_replace('/\s+/u', ' ', trim($m));
        return function_exists('mb_strtolower') ? mb_strtolower($m, 'UTF-8') : strtolower($m);
    }

    private static function is_repo_footer(array $el, string $name): bool
    {
        if (($el['settings']['_olp_footer'] ?? '') === 'yes') {
            return true;
        }
        return strpos(self::element_text($el), self::normalize_marker('[landing_page name="' . $name . '"]')) !== false;
    }

    /** True when the element is, or contains, a widget of one of these types (e.g. a lead form). */
    private static function subtree_has_widget(array $el, array $types): bool
    {
        if (($el['elType'] ?? '') === 'widget' && in_array((string) ($el['widgetType'] ?? ''), $types, true)) {
            return true;
        }
        foreach ((array) ($el['elements'] ?? []) as $child) {
            if (is_array($child) && self::subtree_has_widget($child, $types)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Depth-first over an Elementor element tree. The first element (at any
     * depth) that is the repo footer or carries an old-footer marker becomes
     * THE footer; every later one is removed. Old copies go to $st['backup'].
     */

    /**
     * Is this element the old hand-pasted footer? Marker text present, no form
     * inside, and SHORT. Legal pages (privacy, terms, accessibility) mention
     * the company and its email too; on 2026-09-11 three of them were wiped
     * because the marker alone decided. Length is the guard.
     */

    /**
     * What a visitor would read: the text-bearing setting values of every
     * widget in the subtree (editor, html, titles, labels …), tags stripped.
     * Ids, colours, units and urls are ignored, so the length reflects
     * content, not Elementor's settings bulk.
     */
    private static function visible_text(array $el): string
    {
        static $keys = ['editor', 'html', 'title', 'text', 'description', 'shortcode', 'content', 'caption', 'button_text',
                        'field_label', 'placeholder', 'acceptance_text', 'success_message', 'error_message', 'sub_heading',
                        'heading', 'title_text', 'description_text', 'tab_title', 'tab_content', 'item_title', 'item_description'];
        $parts = [];
        $walk = function ($node) use (&$walk, &$parts, $keys) {
            if (!is_array($node)) { return; }
            foreach ((array) ($node['settings'] ?? []) as $k => $v) {
                if (is_string($v) && in_array((string) $k, $keys, true)) {
                    $parts[] = html_entity_decode(wp_strip_all_tags($v), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                } elseif (is_array($v)) {
                    foreach ($v as $item) {
                        if (!is_array($item)) { continue; }
                        foreach ($item as $ik => $iv) {
                            if (is_string($iv) && in_array((string) $ik, $keys, true)) { $parts[] = html_entity_decode(wp_strip_all_tags($iv), ENT_QUOTES | ENT_HTML5, 'UTF-8'); }
                        }
                    }
                }
            }
            foreach ((array) ($node['elements'] ?? []) as $c) { $walk($c); }
        };
        $walk($el);
        return trim(preg_replace('/\s+/u', ' ', implode(' ', $parts)));
    }

    private static function looks_like_old_footer(array $el, array $markers): bool
    {
        if (self::subtree_has_widget($el, ['form'])) {
            return false;
        }
        $visible = self::visible_text($el);
        $len     = function_exists('mb_strlen') ? mb_strlen($visible, 'UTF-8') : strlen($visible);
        if ($len > self::FOOTER_MAX_CHARS) {
            return false;
        }
        $text = self::element_text($el);
        foreach ($markers as $m) {
            if ($m !== '' && strpos($text, $m) !== false) {
                return true;
            }
        }
        return false;
    }

    /** Footer markers of this site from sites.json (normalized). */
    private static function footer_markers(): array
    {
        $raw   = self::fetch_repo_file('sites.json');
        $sites = $raw !== '' ? json_decode($raw, true) : null;
        $cfg   = is_array($sites) ? ($sites[self::site_host()]['footer'] ?? null) : null;
        if (!is_array($cfg)) {
            return [];
        }
        return array_values(array_filter(array_map([__CLASS__, 'normalize_marker'], array_map('strval', (array) ($cfg['replace_containing'] ?? [])))));
    }

    private static function footer_walk(array $elements, string $name, array $markers, array &$st): array
    {
        $out = [];
        foreach ($elements as $el) {
            if (!is_array($el)) { $out[] = $el; continue; }
            if (self::is_repo_footer($el, $name)) {
                if ($st['seen']) { $st['deduped']++; $st['what'][] = 'dedupe'; continue; }
                $st['seen'] = true;
                // a wrapper whose only content is the repo footer (left by the 1.7.x descend) collapses to the footer itself
                if (($el['settings']['_olp_footer'] ?? '') !== 'yes' && count((array) ($el['elements'] ?? [])) === 1) {
                    $only = $el['elements'][0];
                    if (is_array($only) && ($only['settings']['_olp_footer'] ?? '') === 'yes') { $el = $only; $el['isInner'] = false; $st['what'][] = 'wrapper-collapsed'; }
                }
                $out[] = $el; continue;
            }
            $text = self::element_text($el); $hit = false;
            foreach ($markers as $m) {
                if ($m !== '' && strpos($text, $m) !== false) { $hit = true; break; }
            }
            if ($hit) {
                // A lead form is never a footer, even when its settings carry a marker.
                if (self::subtree_has_widget($el, ['form'])) { $st['what'][] = 'form-protected'; $out[] = $el; continue; }
                if (self::looks_like_old_footer($el, $markers)) {
                    // the whole element is the old footer (short, marker, no form): replace it as one block
                    $st['backup'][] = $el;
                    if ($st['seen']) { $st['deduped']++; $st['what'][] = 'old-dup-removed'; continue; }
                    $st['seen'] = true; $st['replaced']++; $st['what'][] = 'replaced';
                    $out[] = self::footer_element($name); continue;
                }
                if (!empty($el['elements']) && is_array($el['elements'])) {
                    // a long wrapper (legal text + footer, hero + footer …): look inside, keep the rest
                    $el['elements'] = self::footer_walk($el['elements'], $name, $markers, $st);
                    if (empty($el['elements'])) { $st['what'][] = 'empty-wrapper-removed'; continue; }
                    $out[] = $el; continue;
                }
                $out[] = $el; $st['what'][] = 'long-text-protected'; continue; // a long text that merely mentions the company
            }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                $el['elements'] = self::footer_walk($el['elements'], $name, $markers, $st);
                if (empty($el['elements'])) { $st['what'][] = 'empty-wrapper-removed'; continue; }
            }
            $out[] = $el;
        }
        return $out;
    }

    /** Elementor keeps rendered output and CSS per page; drop both so a data change is visible at once. */
    private static function clear_elementor_cache(int $pid): void
    {
        delete_post_meta($pid, '_elementor_css');
        delete_post_meta($pid, '_elementor_element_cache');
        if (class_exists('\Elementor\Plugin') && isset(\Elementor\Plugin::$instance->files_manager) && method_exists(\Elementor\Plugin::$instance->files_manager, 'clear_cache')) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
    }


    /**
     * Elementor keeps a plain-text copy of the page in post_content (used by
     * search, excerpts and SEO plugins for the meta description). It is only
     * rewritten when the page is saved in the editor, so after a programmatic
     * data change the old footer text (old email) lingers there. Ask Elementor
     * to regenerate it.
     */
    private static function refresh_plain_text(int $pid): bool
    {
        if (!class_exists('\Elementor\Plugin') || !isset(\Elementor\Plugin::$instance->documents)) {
            return false;
        }
        $doc = \Elementor\Plugin::$instance->documents->get($pid);
        if ($doc && method_exists($doc, 'save_plain_text')) {
            $doc->save_plain_text();
            return true;
        }
        return false;
    }

    public static function sync_footer(): array
    {
        $raw   = self::fetch_repo_file('sites.json');
        $sites = $raw !== '' ? json_decode($raw, true) : null;
        $log   = [];
        $cfg   = is_array($sites) ? ($sites[self::site_host()]['footer'] ?? null) : null;
        if (!is_array($cfg) || empty($cfg['name'])) {
            $log[] = 'no footer config for ' . self::site_host();
            update_option('olp_last_footer', gmdate('c') . ' ' . implode('; ', $log), false);
            return $log;
        }
        $name    = sanitize_title((string) $cfg['name']);
        $markers = array_values(array_filter(array_map([__CLASS__, 'normalize_marker'], array_map('strval', (array) ($cfg['replace_containing'] ?? [])))));
        $append  = !empty($cfg['append_to_pages_created_from_repo']);

        $pages = get_posts(['post_type' => 'page', 'post_status' => ['publish', 'draft', 'private', 'pending', 'future'], 'numberposts' => -1, 'fields' => 'ids']);
        $replaced = 0; $appended = 0; $deduped = 0; $skipped = 0; $detail = [];
        foreach ((array) $pages as $pid) {
            $pid  = (int) $pid;
            $json = get_post_meta($pid, '_elementor_data', true);
            if (!is_string($json) || $json === '') {
                $detail[] = $pid . ':no-elementor';
                continue;
            }
            $data = json_decode($json, true);
            if (!is_array($data)) {
                $detail[] = $pid . ':bad-json';
                continue;
            }
            $st = ['seen' => false, 'backup' => [], 'what' => [], 'replaced' => 0, 'deduped' => 0];
            $out = self::footer_walk($data, $name, $markers, $st);
            $changed = !empty($st['what']);
            $replaced += $st['replaced']; $deduped += $st['deduped'];
            $seen_footer = $st['seen']; $backup = $st['backup']; $what = $st['what'];
            if (!$seen_footer && $append && get_post_meta($pid, '_olp_created_from', true)) {
                $out[] = self::footer_element($name); $changed = true; $appended++; $what[] = 'appended';
            }
            // the footer is always the last top-level element (a replaced mid-page block left it in the middle)
            $footer_idx = null;
            foreach ($out as $i => $el) {
                if (is_array($el) && self::is_repo_footer($el, $name)) { $footer_idx = $i; break; }
            }
            if ($footer_idx !== null && $footer_idx !== count($out) - 1) {
                $f = $out[$footer_idx]; array_splice($out, $footer_idx, 1); $out[] = $f;
                $changed = true; $what[] = 'footer-moved-to-end';
            }
            if (!$changed) {
                $post = get_post($pid);
                $pc   = $post ? self::normalize_marker(wp_strip_all_tags((string) $post->post_content)) : '';
                foreach ($markers as $m) {
                    if ($m !== '' && $pc !== '' && strpos($pc, $m) !== false) { self::refresh_plain_text($pid); $what[] = 'plain-text-refreshed'; break; }
                }
                $skipped++; $detail[] = $pid . ':' . ($seen_footer ? 'ok' : 'no-footer') . ($what ? '+' . implode('+', $what) : ''); continue;
            }
            if ($backup) {
                $old = get_post_meta($pid, '_olp_footer_backup', true);
                $old = is_array($old) ? $old : [];
                update_post_meta($pid, '_olp_footer_backup', array_merge($old, [['at' => gmdate('c'), 'elements' => $backup]]));
            }
            update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($out, JSON_UNESCAPED_UNICODE)));
            self::clear_elementor_cache($pid);
            self::refresh_plain_text($pid);
            clean_post_cache($pid);
            self::purge_page_cache_plugins($pid);
            $detail[] = $pid . ':' . implode('+', $what);
        }
        $log[] = "footer '$name': replaced $replaced, appended $appended, duplicates removed $deduped, untouched $skipped";
        $log[] = implode(' ', $detail);
        update_option('olp_last_footer', gmdate('c') . ' ' . implode('; ', $log), false);
        return $log;
    }


    /* ---------- converting an existing Elementor page to repo HTML ---------- */

    /**
     * sites.json:
     *   {"orcatribe.co.il": {"convert": [{"page": 114, "name": "orca-home"}]}}
     * A listed page is converted ONCE, and only when pages/<name>/index.html
     * exists in the repo. Before anything changes:
     *   1. the full Elementor design is saved as a template in the library
     *      ("גיבוי – <title>"), and verified by reading it back;
     *   2. the same data, page settings and page template go to post meta
     *      _olp_convert_backup (used by /olp/v1/unconvert).
     * Every lead form keeps working as a real Elementor form: its enclosing
     * container is saved as its own library template ("טופס – <title> #n") and
     * rendered where the HTML says <!--olp:form:n-->. A form whose marker is
     * missing from the HTML is appended at the end, so no form ever disappears.
     * The page address, title, SEO settings and page template are untouched;
     * only the Elementor content becomes one shortcode widget.
     */
    private static $last_error = '';

    private static function save_library_template(string $title, string $type, array $content, array $page_settings = []): int
    {
        $tid = wp_insert_post([
            'post_type'   => 'elementor_library',
            'post_status' => 'publish',
            'post_title'  => $title,
            'post_content'=> '',
        ], true);
        if (is_wp_error($tid) || !$tid) {
            self::$last_error = 'insert: ' . (is_wp_error($tid) ? $tid->get_error_message() : 'returned 0');
            return 0;
        }
        $json = wp_json_encode($content, JSON_UNESCAPED_UNICODE);
        update_post_meta($tid, '_elementor_edit_mode', 'builder');
        update_post_meta($tid, '_elementor_template_type', $type);
        update_post_meta($tid, '_elementor_data', wp_slash($json));
        if ($page_settings) {
            update_post_meta($tid, '_elementor_page_settings', $page_settings);
        }
        if (defined('ELEMENTOR_VERSION')) {
            update_post_meta($tid, '_elementor_version', ELEMENTOR_VERSION);
        }
        wp_set_object_terms($tid, $type, 'elementor_library_type');
        // read it back: a backup that was not written is no backup
        $raw    = get_post_meta($tid, '_elementor_data', true);
        $stored = is_string($raw) ? json_decode($raw, true) : $raw;
        $a = (string) wp_json_encode($stored, JSON_UNESCAPED_UNICODE);
        $b = (string) wp_json_encode($content, JSON_UNESCAPED_UNICODE);
        if ($a !== $b) {
            $i = 0; $n = min(strlen($a), strlen($b));
            while ($i < $n && $a[$i] === $b[$i]) { $i++; }
            self::$last_error = 'readback mismatch: stored ' . gettype($raw) . ' len ' . strlen($a) . ' vs ' . strlen($b) . ' at ' . $i
                . ' stored[' . substr($a, max(0, $i - 40), 90) . '] expected[' . substr($b, max(0, $i - 40), 90) . ']';
            wp_delete_post($tid, true);
            return 0;
        }
        return (int) $tid;
    }

    /** Depth-first: the direct parent (container/section/column) of every form widget, in page order. */
    private static function form_holders(array $elements, array &$out, ?array $parent = null): void
    {
        foreach ($elements as $el) {
            if (!is_array($el)) { continue; }
            if (($el['elType'] ?? '') === 'widget' && ($el['widgetType'] ?? '') === 'form') {
                $holder = $parent ?? $el;
                $ids = array_column($out, 'id');
                if (!in_array($holder['id'] ?? '', $ids, true)) { $out[] = $holder; }
                continue;
            }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                self::form_holders($el['elements'], $out, ($el['elType'] ?? '') === 'widget' ? $parent : $el);
            }
        }
    }

    /**
     * The webhook runs as nobody. Saving Elementor data as a user without
     * unfiltered_html runs it through kses, which rewrites inline styles
     * ("font-weight: 400;" became "font-weight: 400"): the backup would not be
     * the original. A conversion therefore runs as the first administrator.
     */
    /** An element (container or widget) by id, at any depth. */
    private static function find_element(array $elements, string $id): ?array
    {
        foreach ($elements as $el) {
            if (!is_array($el)) { continue; }
            if ((string) ($el['id'] ?? '') === $id) { return $el; }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                $hit = self::find_element($el['elements'], $id);
                if ($hit) { return $hit; }
            }
        }
        return null;
    }

    public static function convert_page(int $pid, string $name, array $keep = [], bool $after_revert = false): string
    {
        $prev = get_current_user_id();
        $admins = get_users(['role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'fields' => 'ID']);
        if (!$admins) {
            return 'no administrator to act as — page untouched';
        }
        wp_set_current_user((int) $admins[0]);
        kses_remove_filters();
        try {
            return self::convert_page_as_admin($pid, $name, $keep, $after_revert);
        } finally {
            wp_set_current_user($prev);
        }
    }

    private static function convert_page_as_admin(int $pid, string $name, array $keep, bool $after_revert = false): string
    {
        $post = get_post($pid);
        if (!$post) {
            return 'no such page';
        }
        if (get_post_meta($pid, '_olp_converted', true)) {
            return 'already converted';
        }
        if (get_post_meta($pid, '_olp_convert_reverted', true) && !$after_revert) {
            return 'reverted — not converting again (set "after_revert": true to convert again)';
        }
        [$html, $source] = self::get_page($name, true);
        if ($html === '' || strpos($source, 'error') === 0) {
            return 'html pages/' . $name . ' missing — waiting';
        }
        $json = get_post_meta($pid, '_elementor_data', true);
        $data = is_string($json) && $json !== '' ? json_decode($json, true) : null;
        if (!is_array($data)) {
            return 'not an elementor page';
        }
        foreach ($keep as $kid) {
            if (!self::find_element($data, (string) $kid)) {
                return 'keep ' . $kid . ' not found — page untouched';
            }
        }
        $page_settings = get_post_meta($pid, '_elementor_page_settings', true);
        $page_settings = is_array($page_settings) ? $page_settings : [];
        $title = html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8');
        $stamp = wp_date('d/m/Y');

        $backup_tid = self::save_library_template('גיבוי – ' . $title . ' – ' . $stamp, 'page', $data, $page_settings);
        if (!$backup_tid) {
            return 'backup template failed (' . self::$last_error . ') — page untouched';
        }
        // update_post_meta unslashes nested values too: slash the JSON or its escapes are lost
        update_post_meta($pid, '_olp_convert_backup', [
            'at' => gmdate('c'), 'template' => $backup_tid, 'data' => wp_slash($json),
            'page_settings' => $page_settings, 'wp_template' => (string) get_post_meta($pid, '_wp_page_template', true),
        ]);

        $holders = [];
        self::form_holders($data, $holders);
        $forms = [];
        foreach ($holders as $i => $holder) {
            $el = $holder;
            $el['isInner'] = false;
            if (($el['elType'] ?? '') === 'widget') {
                $el = ['id' => self::new_id(), 'elType' => 'container', 'isInner' => false, 'settings' => ['content_width' => 'full'], 'elements' => [$holder]];
            }
            $tid = self::save_library_template('טופס – ' . $title . ' #' . ($i + 1), 'container', [$el]);
            if (!$tid) {
                return 'form template ' . ($i + 1) . ' failed (' . self::$last_error . ') — page untouched (backup #' . $backup_tid . ' kept)';
            }
            $forms[] = $tid;
        }

        $kept = [];
        foreach ($keep as $kid) {
            $el = self::find_element($data, (string) $kid);
            $el['isInner'] = false;
            if (($el['elType'] ?? '') === 'widget') {
                $el = ['id' => self::new_id(), 'elType' => 'container', 'isInner' => false,
                       'settings' => ['content_width' => 'full', 'css_classes' => 'olp-wrap', 'padding' => ['unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true]],
                       'elements' => [self::find_element($data, (string) $kid)]];
            }
            $tid = self::save_library_template('רכיב – ' . $title . ' – ' . $kid, 'container', [$el]);
            if (!$tid) {
                return 'keep template ' . $kid . ' failed (' . self::$last_error . ') — page untouched (backup #' . $backup_tid . ' kept)';
            }
            $kept[(string) $kid] = $tid;
        }

        $new = [[
            'id' => self::new_id(), 'elType' => 'container', 'isInner' => false,
            'settings' => ['content_width' => 'full', 'flex_direction' => 'column', 'flex_gap' => ['unit' => 'px', 'size' => 0, 'column' => '0', 'row' => '0'],
                           'padding' => ['unit' => 'px', 'top' => '0', 'right' => '0', 'bottom' => '0', 'left' => '0', 'isLinked' => true], '_olp_converted' => 'yes'],
            'elements' => [[
                'id' => self::new_id(), 'elType' => 'widget', 'widgetType' => 'shortcode', 'elements' => [],
                'settings' => ['shortcode' => '[landing_page name="' . $name . '"]'],
            ]],
        ]];
        update_post_meta($pid, '_olp_forms', $forms);
        update_post_meta($pid, '_olp_keep', $kept);
        update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($new, JSON_UNESCAPED_UNICODE)));
        update_post_meta($pid, '_olp_converted', $name . '@' . gmdate('c'));
        delete_post_meta($pid, '_olp_convert_reverted');
        self::clear_elementor_cache($pid);
        self::refresh_plain_text($pid);
        clean_post_cache($pid);
        self::purge_page_cache_plugins($pid);
        return 'converted (backup #' . $backup_tid . ', forms ' . ($forms ? implode(',', $forms) : 'none') . ', kept ' . ($kept ? count($kept) : 0) . ')';
    }

    /** Put the original Elementor design back from _olp_convert_backup, and never convert this page again. */
    public static function unconvert_page(int $pid): array
    {
        $admins = get_users(['role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'fields' => 'ID']);
        if ($admins) {
            wp_set_current_user((int) $admins[0]);
            kses_remove_filters();
        }
        $b = get_post_meta($pid, '_olp_convert_backup', true);
        if (!is_array($b) || empty($b['data'])) {
            return ['page' => $pid, 'error' => 'no conversion backup'];
        }
        // the library template was verified byte-for-byte at conversion time; 1.9.x-1.10.0 stored a broken copy in page meta
        $json = !empty($b['template']) ? get_post_meta((int) $b['template'], '_elementor_data', true) : '';
        if (!is_string($json) || !is_array(json_decode($json, true))) {
            $json = (string) $b['data'];
        }
        if (!is_array(json_decode($json, true))) {
            return ['page' => $pid, 'error' => 'backup unreadable — restore from the library template by hand'];
        }
        update_post_meta($pid, '_elementor_data', wp_slash($json));
        update_post_meta($pid, '_elementor_page_settings', is_array($b['page_settings'] ?? null) ? $b['page_settings'] : []);
        if (!empty($b['wp_template'])) {
            update_post_meta($pid, '_wp_page_template', (string) $b['wp_template']);
        }
        delete_post_meta($pid, '_olp_converted');
        delete_post_meta($pid, '_olp_forms');
        delete_post_meta($pid, '_olp_keep');
        update_post_meta($pid, '_olp_convert_reverted', gmdate('c'));
        self::clear_elementor_cache($pid);
        self::refresh_plain_text($pid);
        clean_post_cache($pid);
        self::purge_page_cache_plugins($pid);
        return ['page' => $pid, 'restored_from' => gmdate('c', strtotime((string) $b['at'])), 'backup_template' => (int) ($b['template'] ?? 0)];
    }

    public static function sync_conversions(): array
    {
        $raw   = self::fetch_repo_file('sites.json');
        $sites = $raw !== '' ? json_decode($raw, true) : null;
        $list  = is_array($sites) ? ($sites[self::site_host()]['convert'] ?? null) : null;
        $log   = [];
        if (!is_array($list)) {
            $log[] = 'no conversions for ' . self::site_host();
        } else {
            foreach ($list as $entry) {
                $pid  = (int) ($entry['page'] ?? 0);
                $name = strtolower(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($entry['name'] ?? '')));
                if ($pid <= 0 || $name === '') {
                    continue;
                }
                $keep = array_values(array_filter(array_map(static function ($k) { return preg_replace('/[^a-z0-9]/', '', strtolower((string) $k)); }, (array) ($entry['keep'] ?? []))));
                $log[] = $pid . ' → ' . $name . ': ' . self::convert_page($pid, $name, $keep, !empty($entry['after_revert']));
            }
        }
        update_option('olp_last_convert', gmdate('c') . ' ' . implode('; ', $log), false);
        return $log;
    }

    /**
     * Rendered form templates of the page being viewed, keyed 1..n, and kept
     * Elementor elements at <!--olp:keep:ID-->. The template wrappers are
     * display:contents, so a kept element sits in the HTML's layout exactly
     * where the original element was.
     */
    private static function render_forms(string $html, int $pid = 0): string
    {
        $pid   = $pid > 0 ? $pid : (int) get_queried_object_id();
        $forms = $pid > 0 ? get_post_meta($pid, '_olp_forms', true) : [];
        $kept  = $pid > 0 ? get_post_meta($pid, '_olp_keep', true) : [];
        if (!class_exists('\Elementor\Plugin') || ((!is_array($forms) || !$forms) && (!is_array($kept) || !$kept))) {
            return $html;
        }
        $forms = is_array($forms) ? $forms : [];
        $html  = '<style>.olp-keep,.olp-form,.olp-keep>.elementor,.olp-form>.elementor,.olp-keep .e-con.olp-wrap{display:contents}</style>' . $html;
        foreach ((is_array($kept) ? $kept : []) as $kid => $tid) {
            $marker = '<!--olp:keep:' . $kid . '-->';
            if (strpos($html, $marker) === false) {
                continue;
            }
            $out  = \Elementor\Plugin::$instance->frontend->get_builder_content_for_display((int) $tid, true);
            $html = str_replace($marker, '<div class="olp-keep" data-olp-keep="' . esc_attr((string) $kid) . '">' . $out . '</div>', $html);
        }
        $tail = '';
        foreach (array_values($forms) as $i => $tid) {
            $out    = \Elementor\Plugin::$instance->frontend->get_builder_content_for_display((int) $tid, true);
            $marker = '<!--olp:form:' . ($i + 1) . '-->';
            if (strpos($html, $marker) !== false) {
                $html = str_replace($marker, '<div class="olp-form" data-olp-form="' . ($i + 1) . '">' . $out . '</div>', $html);
            } else {
                $tail .= '<div class="olp-form" data-olp-form="' . ($i + 1) . '">' . $out . '</div>'; // never lose a form
            }
        }
        return $html . $tail;
    }


    /* ---------- blog: posts and the blog index wear the site's own design ---------- */

    /**
     * sites.json: {"orcatribe.co.il": {"blog": {"post_page": "orca-blog-post", "index_page": "orca-blog",
     *   "category": "blog", "form_page": 114}}}
     * (Jonathan, 02/10/2026) A post published through WordPress came out in the bare default theme: no header,
     * no footer, no lead form. Every post and the blog category page are now rendered inside a repo page, the
     * same way the service pages are, so one push restyles every article at once. The repo page holds markers:
     *   <!--olp:post-title-->  <!--olp:post-date-->  <!--olp:post-reading-->  <!--olp:post-content-->
     *   <!--olp:posts-->       (the cards on the index)
     *   <!--olp:form:1-->      (the Elementor lead form of form_page, the home page)
     * A FAQ section in the article ("שאלות נפוצות" + question/answer pairs) becomes FAQPage data for Google.
     */
    public static function sync_blog(): void
    {
        $raw   = self::fetch_repo_file('sites.json');
        $sites = $raw !== '' ? json_decode($raw, true) : null;
        $cfg   = is_array($sites) ? ($sites[self::site_host()]['blog'] ?? null) : null;
        if (is_array($cfg) && !empty($cfg['post_page'])) {
            update_option(self::BLOG_OPTION, $cfg, false);
        } elseif ($raw !== '') {
            update_option(self::BLOG_OPTION, ['off' => 1], false);
        }
    }

    public static function blog_cfg(): array
    {
        $cfg = get_option(self::BLOG_OPTION, null);
        if (!is_array($cfg) && !get_transient('olp_blog_synced')) {   // first request after an update, before any push
            set_transient('olp_blog_synced', 1, 10 * MINUTE_IN_SECONDS);
            self::sync_blog();
            $cfg = get_option(self::BLOG_OPTION, null);
        }
        return (is_array($cfg) && empty($cfg['off'])) ? $cfg : [];
    }

    public static function blog_template($template)
    {
        if (is_admin() || is_feed() || is_embed() || isset($_GET['olp_theme'])) {
            return $template;
        }
        $cfg = self::blog_cfg();
        if (!$cfg) {
            return $template;
        }
        if (is_singular('post') && !empty($cfg['post_page'])) {
            self::$blog_mode = 'post';
        } elseif (is_category((string) ($cfg['category'] ?? 'blog')) && !empty($cfg['index_page'])) {
            self::$blog_mode = 'index';
        } else {
            return $template;
        }
        add_action('wp_enqueue_scripts', [__CLASS__, 'blog_enqueue_form_assets'], 20);
        return __DIR__ . '/blog-template.php';
    }

    /** The lead form is an Elementor widget; a post page does not load Elementor's front-end by itself. */
    public static function blog_enqueue_form_assets(): void
    {
        if (class_exists('\Elementor\Plugin')) {
            $fe = \Elementor\Plugin::$instance->frontend;
            if (method_exists($fe, 'enqueue_styles')) { $fe->enqueue_styles(); }
            if (method_exists($fe, 'enqueue_scripts')) { $fe->enqueue_scripts(); }
        }
        if (class_exists('\ElementorPro\Plugin')) {
            $pro = \ElementorPro\Plugin::instance();
            if (method_exists($pro, 'enqueue_styles')) { $pro->enqueue_styles(); }
            if (method_exists($pro, 'enqueue_frontend_scripts')) { $pro->enqueue_frontend_scripts(); }
        }
    }

    public static function blog_date(int $ts): string
    {
        return date_i18n('j בF Y', $ts);
    }

    public static function blog_body(): string
    {
        $cfg  = self::blog_cfg();
        $mode = self::$blog_mode;
        $name = strtolower(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) ($mode === 'post' ? ($cfg['post_page'] ?? '') : ($cfg['index_page'] ?? ''))));
        [$html, $source] = $name !== '' ? self::get_page($name, isset($_GET['olp_refresh']) && current_user_can('edit_pages')) : ['', 'no page'];

        if ($mode === 'post') {
            $post = get_queried_object();
            if (!$post instanceof WP_Post) {
                return '';
            }
            $GLOBALS['post'] = $post;
            setup_postdata($post);
            $content = apply_filters('the_content', get_the_content(null, false, $post));
            $content = str_replace(']]>', ']]&gt;', $content);
            wp_reset_postdata();
            if ($html === '') {   // the repo is unreachable and nothing is cached: still show the article
                return '<!-- olp blog: ' . esc_html($source) . ' --><main dir="rtl" style="max-width:760px;margin:40px auto;padding:0 20px"><h1>'
                    . esc_html(get_the_title($post)) . '</h1>' . $content . '</main>';
            }
            $words = max(1, (int) round(mb_strlen(wp_strip_all_tags($content)) / 1100));
            $html  = strtr($html, [
                '<!--olp:post-title-->'   => esc_html(get_the_title($post)),
                '<!--olp:post-date-->'    => esc_html(self::blog_date((int) get_post_time('U', false, $post))),
                '<!--olp:post-reading-->' => esc_html($words . ' דקות קריאה'),
                '<!--olp:post-content-->' => $content,
            ]);
            $faq = self::faq_from_content($content);
            if ($faq) {
                $html .= '<script type="application/ld+json">' . wp_json_encode($faq, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . '</script>';
            }
        } else {
            if ($html === '') {
                return '<!-- olp blog index: ' . esc_html($source) . ' -->';
            }
            $html = str_replace('<!--olp:posts-->', self::blog_cards($cfg), $html);
        }

        return '<div class="olp-page olp-blog" data-olp-page="' . esc_attr($name) . '" data-olp-source="' . esc_attr($source) . '">'
            . self::render_forms($html, (int) ($cfg['form_page'] ?? 0)) . '</div>';
    }

    public static function blog_cards(array $cfg): string
    {
        $cat = get_category_by_slug((string) ($cfg['category'] ?? 'blog'));
        $q   = new WP_Query([
            'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 60, 'no_found_rows' => true,
            'cat' => $cat ? (int) $cat->term_id : 0,
        ]);
        if (!$q->have_posts()) {
            return '<p class="olp-posts-empty">המאמרים הראשונים בדרך.</p>';
        }
        $out = '';
        foreach ($q->posts as $p) {
            $ex  = has_excerpt($p) ? (string) $p->post_excerpt : wp_trim_words(wp_strip_all_tags((string) $p->post_content), 30, '…');
            $img = get_the_post_thumbnail_url($p, 'large');
            $out .= '<a class="olp-post-card" href="' . esc_url(get_permalink($p)) . '">'
                . ($img ? '<img src="' . esc_url($img) . '" alt="" loading="lazy">' : '')
                . '<span class="olp-post-date">' . esc_html(self::blog_date((int) get_post_time('U', false, $p))) . '</span>'
                . '<h2>' . esc_html(get_the_title($p)) . '</h2><p>' . esc_html($ex) . '</p>'
                . '<span class="olp-post-more">לקריאת המאמר ←</span></a>';
        }
        return '<div class="olp-posts">' . $out . '</div>';
    }

    /** "שאלות נפוצות" heading followed by <h3>Q</h3><p>A</p> or <p><strong>Q</strong></p><p>A</p> pairs. */
    public static function faq_from_content(string $html): array
    {
        if (!preg_match('/<h2[^>]*>\s*שאלות נפוצות\s*<\/h2>(.*?)(?=<h2|$)/su', $html, $m)) {
            return [];
        }
        $items = [];
        if (preg_match_all('/<(?:h3[^>]*>(.*?)<\/h3>|p[^>]*>\s*<strong>(.*?)<\/strong>\s*<\/p>)\s*<p[^>]*>(.*?)<\/p>/su', $m[1], $mm, PREG_SET_ORDER)) {
            foreach ($mm as $x) {
                $q = trim(html_entity_decode(wp_strip_all_tags($x[1] !== '' ? $x[1] : $x[2])));
                $a = trim(html_entity_decode(wp_strip_all_tags($x[3])));
                if ($q !== '' && $a !== '') {
                    $items[] = ['@type' => 'Question', 'name' => $q, 'acceptedAnswer' => ['@type' => 'Answer', 'text' => $a]];
                }
            }
        }
        return count($items) >= 2 ? ['@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $items] : [];
    }


    /* ---------- consent text: the privacy policy is always a visible link ---------- */

    /**
     * sites.json: {"orcatribe.co.il": {"privacy_link": {"text": "מדיניות פרטיות",
     *   "url": "https://www.orcatribe.co.il/מדיניות-פרטיות/", "color": "#32e9da"}}}
     * Rule (Jonathan, 25/09/2026): wherever a form's consent text mentions the privacy
     * policy, those words are a prominent coloured link to the privacy page. Done here,
     * once for the whole site, so every form (and every future one, popups included) obeys it.
     */
    public static function sync_privacy_link(): void
    {
        $raw   = self::fetch_repo_file('sites.json');
        $sites = $raw !== '' ? json_decode($raw, true) : null;
        $cfg   = is_array($sites) ? ($sites[self::site_host()]['privacy_link'] ?? null) : null;
        if (is_array($cfg) && !empty($cfg['text']) && !empty($cfg['url'])) {
            update_option('olp_privacy_link', ['text' => (string) $cfg['text'], 'url' => esc_url_raw((string) $cfg['url']), 'color' => preg_match('/^#[0-9a-f]{3,8}$/i', (string) ($cfg['color'] ?? '')) ? (string) $cfg['color'] : '#32e9da'], false);
        } else {
            delete_option('olp_privacy_link');
        }
    }

    public static function privacy_link_script(): void
    {
        $cfg = get_option('olp_privacy_link');
        if (!is_array($cfg) || empty($cfg['text']) || empty($cfg['url'])) {
            return;
        }
        $data = wp_json_encode(['t' => $cfg['text'], 'u' => $cfg['url']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        echo '<style>a.olp-privacy-link,a.olp-privacy-link:visited{color:' . esc_attr($cfg['color']) . ' !important;font-weight:700 !important;text-decoration:underline !important;text-underline-offset:3px}a.olp-privacy-link:hover{opacity:.85}</style>';
        echo '<script>(function(c){function run(root){(root||document).querySelectorAll(".elementor-form a").forEach(function(a){if(a.textContent.indexOf(c.t)>-1){a.classList.add("olp-privacy-link");a.href=c.u;a.target="_blank";a.rel="noopener";}});(root||document).querySelectorAll(".elementor-form label,.elementor-form .elementor-field-type-html,.elementor-form .elementor-field-type-acceptance").forEach(function(el){if(el.querySelector("a.olp-privacy-link"))return;var w=document.createTreeWalker(el,NodeFilter.SHOW_TEXT),n;while((n=w.nextNode())){if(n.parentNode.closest("a"))continue;var i=n.nodeValue.indexOf(c.t);if(i<0)continue;var after=n.splitText(i);after.nodeValue=after.nodeValue.slice(c.t.length);var a=document.createElement("a");a.className="olp-privacy-link";a.href=c.u;a.target="_blank";a.rel="noopener";a.textContent=c.t;a.addEventListener("click",function(e){e.stopPropagation();});n.parentNode.insertBefore(a,after);break;}});}if(document.readyState!=="loading")run();else document.addEventListener("DOMContentLoaded",function(){run();});if(window.jQuery){jQuery(document).on("elementor/popup/show",function(){run();});}})(' . $data . ');</script>';
    }


    /* ---------- restore what a footer sync removed ---------- */

    /**
     * Re-insert, from _olp_footer_backup, the elements that hold a lead form
     * (the only thing the sync should never have taken). They go right before
     * the first repo footer, or at the end. Optionally remove top-level
     * elements by id (leftover hand-pasted HTML widgets). Secret-protected REST:
     *   POST /wp-json/olp/v1/restore?secret=…&page=485[&remove=32821c0,85ccef9]
     */

    /** Remove elements by id at any depth, never one that holds a form. */
    private static function remove_ids_deep(array $elements, array $ids, array &$removed): array
    {
        $out = [];
        foreach ($elements as $el) {
            if (!is_array($el)) { $out[] = $el; continue; }
            $id = (string) ($el['id'] ?? '');
            if ($id !== '' && in_array($id, $ids, true) && !self::subtree_has_widget($el, ['form'])) { $removed[] = $id; continue; }
            if (!empty($el['elements']) && is_array($el['elements'])) {
                $el['elements'] = self::remove_ids_deep($el['elements'], $ids, $removed);
            }
            $out[] = $el;
        }
        return $out;
    }


    /** Pages whose Elementor data holds no form widget while their footer backup does. */
    public static function pages_missing_forms(): array
    {
        $out = [];
        foreach ((array) get_posts(['post_type' => 'page', 'post_status' => ['publish', 'draft', 'private', 'pending', 'future'], 'numberposts' => -1, 'fields' => 'ids']) as $pid) {
            $backup = get_post_meta((int) $pid, '_olp_footer_backup', true);
            if (is_array($backup) && $backup) { $out[] = (int) $pid; } // restore_forms() decides per element what is missing
        }
        return $out;
    }

    /** Exact string replacement in every string value of the page's Elementor data, at any depth. */
    public static function replace_in_page(int $pid, string $find, string $repl): array
    {
        $json = get_post_meta($pid, '_elementor_data', true);
        $data = is_string($json) && $json !== '' ? json_decode($json, true) : null;
        if (!is_array($data)) {
            return ['error' => 'no elementor data'];
        }
        $count = 0;
        $walk = function (&$node) use (&$walk, $find, $repl, &$count) {
            if (is_array($node)) {
                foreach ($node as &$v) { $walk($v); }
                unset($v);
            } elseif (is_string($node) && strpos($node, $find) !== false) {
                $count += substr_count($node, $find);
                $node = str_replace($find, $repl, $node);
            }
        };
        $walk($data);
        if ($count > 0) {
            update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($data, JSON_UNESCAPED_UNICODE)));
            self::clear_elementor_cache($pid);
            self::refresh_plain_text($pid);
            clean_post_cache($pid);
            self::purge_page_cache_plugins($pid);
        }
        return ['page' => $pid, 'replacements' => $count];
    }

    /**
     * Change the type of one field (by its ID) in every form widget of a post,
     * nothing else. Found 25/09/2026: the orcatribe home form had its "full
     * name" field set to tel, so every name typed in letters was rejected.
     */
    public static function set_form_field_type(int $pid, string $field_id, string $type, ?bool $required = null): array
    {
        $json = get_post_meta($pid, '_elementor_data', true);
        $data = is_string($json) && $json !== '' ? json_decode($json, true) : null;
        if (!is_array($data)) {
            return ['error' => 'no elementor data'];
        }
        $changed = [];
        $walk = function (array &$els) use (&$walk, $field_id, $type, $required, &$changed) {
            foreach ($els as &$el) {
                if (!is_array($el)) { continue; }
                if (($el['widgetType'] ?? '') === 'form' && !empty($el['settings']['form_fields']) && is_array($el['settings']['form_fields'])) {
                    foreach ($el['settings']['form_fields'] as &$f) {
                        if (($f['custom_id'] ?? '') !== $field_id) { continue; }
                        if ($type !== '' && ($f['field_type'] ?? 'text') !== $type) {
                            $changed[] = ($f['field_type'] ?? 'text') . ' → ' . $type;
                            $f['field_type'] = $type;
                        }
                        if ($type === 'acceptance' && trim((string) ($f['acceptance_text'] ?? '')) === '' && trim((string) ($f['field_options'] ?? '')) !== '') {
                            // a checkbox keeps its wording in field_options; an acceptance field reads acceptance_text, so carry the text over
                            $f['acceptance_text'] = trim(strtok((string) $f['field_options'], "\n"));
                            $changed[] = 'acceptance_text ← field_options';
                        }
                        if ($required !== null && (($f['required'] ?? '') === 'true') !== $required) {
                            // Elementor stores the switch as the string 'true'; anything else means optional
                            $changed[] = 'required → ' . ($required ? 'yes' : 'no');
                            $f['required'] = $required ? 'true' : '';
                        }
                    }
                    unset($f);
                }
                if (!empty($el['elements']) && is_array($el['elements'])) { $walk($el['elements']); }
            }
            unset($el);
        };
        $walk($data);
        if ($changed) {
            $admins = get_users(['role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'fields' => 'ID']);
            if ($admins) { wp_set_current_user((int) $admins[0]); kses_remove_filters(); }
            update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($data, JSON_UNESCAPED_UNICODE)));
            self::clear_elementor_cache($pid);
            clean_post_cache($pid);
            self::touch_landing_pages();
        }
        return ['post' => $pid, 'field' => $field_id, 'changed' => $changed];
    }

    /**
     * Change what a form does after submit, in every form widget of a post:
     * remove and/or add after-submit actions, and optionally set the webhook
     * URL. Nothing else in the form is touched.
     */
    public static function set_form_actions(int $pid, array $remove, array $add, string $webhook = '', ?bool $advanced = null, ?array $metadata = null, string $form_name = '', string $redirect = ''): array
    {
        $json = get_post_meta($pid, '_elementor_data', true);
        $data = is_string($json) && $json !== '' ? json_decode($json, true) : null;
        if (!is_array($data)) {
            return ['error' => 'no elementor data'];
        }
        $report = [];
        $walk = function (array &$els) use (&$walk, $remove, $add, $webhook, $advanced, $metadata, $form_name, $redirect, &$report) {
            foreach ($els as &$el) {
                if (!is_array($el)) { continue; }
                if (($el['widgetType'] ?? '') === 'form') {
                    $before = array_values((array) ($el['settings']['submit_actions'] ?? []));
                    $after  = array_values(array_unique(array_merge(array_diff($before, $remove), $add)));
                    $el['settings']['submit_actions'] = $after;
                    if ($webhook !== '') {
                        $el['settings']['webhooks'] = $webhook;
                    }
                    if ($redirect !== '') {
                        // where the visitor lands after a successful send (the 'redirect' action must be in the list)
                        $el['settings']['redirect_to'] = $redirect;
                        // a leftover dynamic tag on the same setting (an "internal url" to a page that no longer exists) would
                        // override the plain address at submit time, so the plain address wins
                        if (isset($el['settings']['__dynamic__']['redirect_to'])) {
                            unset($el['settings']['__dynamic__']['redirect_to']);
                            if (empty($el['settings']['__dynamic__'])) { unset($el['settings']['__dynamic__']); }
                        }
                    }
                    if ($form_name !== '') {
                        // the form's name travels with every submission, so a webhook can tell which page it came from
                        $el['settings']['form_name'] = $form_name;
                    }
                    if ($metadata !== null) {
                        // which of Elementor's meta fields (page_url, date, time, remote_ip, user_agent, credit) ride along with every submission
                        $el['settings']['form_metadata'] = array_values($metadata);
                    }
                    if ($advanced !== null) {
                        // Elementor's "advanced data": the webhook gets form name, every field with its id, and meta (page url, date, ip)
                        $el['settings']['webhooks_advanced_data'] = $advanced ? 'yes' : ''; // Elementor's switcher stores 'yes', anything else counts as off
                    }
                    $report[] = ['form' => $el['id'] ?? '?', 'before' => $before, 'after' => $after, 'webhook_set' => $webhook !== '', 'advanced' => $advanced, 'metadata' => $metadata, 'form_name' => $form_name, 'redirect' => $redirect];
                }
                if (!empty($el['elements']) && is_array($el['elements'])) { $walk($el['elements']); }
            }
            unset($el);
        };
        $walk($data);
        if ($report) {
            $admins = get_users(['role' => 'administrator', 'number' => 1, 'orderby' => 'ID', 'fields' => 'ID']);
            if ($admins) { wp_set_current_user((int) $admins[0]); kses_remove_filters(); }
            update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($data, JSON_UNESCAPED_UNICODE)));
            self::clear_elementor_cache($pid);
            clean_post_cache($pid);
            self::touch_landing_pages();
        }
        return ['post' => $pid, 'forms' => $report];
    }

    public static function restore_forms(int $pid, array $remove_ids = []): array
    {
        $json = get_post_meta($pid, '_elementor_data', true);
        $data = is_string($json) && $json !== '' ? json_decode($json, true) : null;
        if (!is_array($data)) {
            return ['error' => 'no elementor data'];
        }
        $backup  = get_post_meta($pid, '_olp_footer_backup', true);
        $backup  = is_array($backup) ? $backup : [];
        $current = (string) wp_json_encode($data, JSON_UNESCAPED_UNICODE);
        $forms   = [];
        $markers = self::footer_markers();
        foreach ($backup as $run) {
            foreach ((array) ($run['elements'] ?? []) as $el) {
                if (!is_array($el) || strpos($current, '"' . ($el['id'] ?? '?') . '"') !== false) {
                    continue; // still in the page
                }
                if (self::subtree_has_widget($el, ['form']) || !self::looks_like_old_footer($el, $markers)) {
                    $forms[] = $el; // forms, legal text, anything that is not the old footer itself
                }
            }
        }
        $removed = [];
        if ($remove_ids) {
            $data = self::remove_ids_deep($data, $remove_ids, $removed);
        }
        // empty wrappers left behind by a replaced form (no widgets at any depth) go too
        $before = count($data);
        $data = array_values(array_filter($data, function ($el) use (&$removed) {
            if (!is_array($el) || ($el['elType'] ?? '') === 'widget') { return true; }
            $has_widget = false;
            $probe = function ($n) use (&$probe, &$has_widget) { if (($n['elType'] ?? '') === 'widget') { $has_widget = true; return; } foreach ((array) ($n['elements'] ?? []) as $c) { if (is_array($c)) { $probe($c); } } };
            $probe($el);
            if (!$has_widget && !empty($el['id'])) { $removed[] = (string) $el['id'] . ' (empty)'; return false; }
            return true;
        }));
        $inserted = 0;
        if ($forms) {
            $pos = count($data);
            foreach ($data as $i => $el) {
                if (is_array($el) && (($el['settings']['_olp_footer'] ?? '') === 'yes')) { $pos = $i; break; }
            }
            array_splice($data, $pos, 0, $forms);
            $inserted = count($forms);
        }
        if ($inserted || $removed) {
            update_post_meta($pid, '_elementor_data', wp_slash(wp_json_encode($data, JSON_UNESCAPED_UNICODE)));
            self::clear_elementor_cache($pid);
            self::refresh_plain_text($pid);
            clean_post_cache($pid);
            self::purge_page_cache_plugins($pid);
        }
        return ['page' => $pid, 'forms_restored' => $inserted, 'removed' => $removed, 'top_level' => count($data)];
    }

    /* ---------- server page cache ---------- */

    /**
     * Page-cache plugins keep a static copy of the page; ask each one that is
     * installed to drop this page. SpeedyCache (Softaculous) is what runs on
     * influence-club.co.il: it stamps "Cache by SpeedyCache" at the end of the
     * HTML and strips comments, so measure with a visible marker, not a comment.
     */
    public static function purge_page_cache_plugins(int $id): array
    {
        $done = [];
        if (class_exists('\\SpeedyCache\\Delete') && method_exists('\\SpeedyCache\\Delete', 'cache')) {
            \SpeedyCache\Delete::cache($id);
            $done[] = 'speedycache';
        }
        if (function_exists('rocket_clean_post')) {
            rocket_clean_post($id);
            $done[] = 'wp-rocket';
        }
        if (function_exists('w3tc_flush_post')) {
            w3tc_flush_post($id);
            $done[] = 'w3tc';
        }
        if (function_exists('wpsc_delete_post_cache')) {
            wpsc_delete_post_cache($id);
            $done[] = 'wp-super-cache';
        }
        if (has_action('litespeed_purge_post')) {
            do_action('litespeed_purge_post', $id);
            $done[] = 'litespeed';
        }
        if (has_action('cache_enabler_clear_page_cache_by_post')) {
            do_action('cache_enabler_clear_page_cache_by_post', $id);
            $done[] = 'cache-enabler';
        }
        if (has_action('wphb_clear_page_cache')) {
            do_action('wphb_clear_page_cache', $id);
            $done[] = 'hummingbird';
        }
        return $done;
    }

    /**
     * FastCloud (cPanel + NGINX caching) keeps the rendered page until the cache
     * is cleared; TTL and save hooks did not do it. cPanel's own API can:
     * UAPI NginxCaching::clear_cache, authenticated with a cPanel API token
     * (cPanel → Manage API Tokens). Configured in the settings page; a no-op
     * until host, user and token are all set. Returns a short status string.
     */
    public static function cpanel_clear_cache(): string
    {
        $s = self::settings();
        if ($s['cpanel_host'] === '' || $s['cpanel_user'] === '' || $s['cpanel_token'] === '') {
            return 'not configured';
        }
        $host = preg_replace('#^https?://#', '', $s['cpanel_host']);
        $host = rtrim($host, '/');
        if (strpos($host, ':') === false) {
            $host .= ':2083';
        }
        $res = wp_remote_get('https://' . $host . '/execute/NginxCaching/clear_cache', [
            'timeout'   => 15,
            'sslverify' => true,
            'headers'   => [
                'Authorization' => 'cpanel ' . $s['cpanel_user'] . ':' . $s['cpanel_token'],
                'User-Agent'    => 'orca-landing-pages/' . self::VERSION,
            ],
        ]);
        if (is_wp_error($res)) {
            $out = 'error: ' . $res->get_error_message();
        } else {
            $code = (int) wp_remote_retrieve_response_code($res);
            $data = json_decode((string) wp_remote_retrieve_body($res), true);
            $ok   = is_array($data) && !empty($data['status']);
            $out  = $ok ? 'cleared' : ('failed: HTTP ' . $code . ' ' . substr((string) wp_remote_retrieve_body($res), 0, 120));
        }
        update_option('olp_last_cpanel_purge', gmdate('c') . ' ' . $out, false);
        return $out;
    }

    /** Every published page or post that renders a landing page. */
    public static function landing_page_ids(): array
    {
        global $wpdb;
        $ids = $wpdb->get_col(
            "SELECT p.ID FROM {$wpdb->posts} p
             LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_elementor_data'
             WHERE p.post_status = 'publish' AND p.post_type IN ('page', 'post')
               AND (p.post_content LIKE '%[landing_page%' OR m.meta_value LIKE '%landing_page%')"
        );
        return array_values(array_unique(array_map('intval', (array) $ids)));
    }

    /**
     * The host's full-page cache (nginx in front of PHP on FastCloud) kept the
     * old HTML for over 15 minutes after GitHub changed, and only let go when
     * the page was published from the editor. So a purge does what the editor
     * does: it saves each landing page again, unchanged, which fires the same
     * save_post / transition_post_status hooks the host's cache listens to.
     * Also clears WordPress' own post cache and, when present, the common
     * caching plugins' full-purge hooks.
     */
    public static function touch_landing_pages(): array
    {
        $ids = self::landing_page_ids();
        foreach ($ids as $id) {
            // bump the modified time directly; wp_update_post() ran every plugin's save hooks inside the
            // anonymous push-hook request, and that is the prime suspect for the 500s since 26/09
            global $wpdb;
            $wpdb->update($wpdb->posts, ['post_modified' => current_time('mysql'), 'post_modified_gmt' => current_time('mysql', true)], ['ID' => $id]);
            clean_post_cache($id);
            self::step('purge_page_cache:' . $id, static function () use ($id) { return Orca_Landing_Pages::purge_page_cache_plugins($id); });
        }
        foreach (['litespeed_purge_all', 'w3tc_flush_all', 'wp_cache_clear_cache', 'rocket_clean_domain', 'cache_enabler_clear_complete_cache', 'breeze_clear_all_cache', 'swcfpc_purge_cache'] as $hook) {
            if (has_action($hook) || has_filter($hook)) {
                do_action($hook);
            }
        }
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }
        return $ids;
    }

    /** Does this post render a landing page? Elementor keeps the shortcode in
     *  post meta, the block editor keeps it in post_content; check both. */
    public static function post_uses_landing_page(int $post_id): bool
    {
        if ($post_id <= 0) {
            return false;
        }
        $post = get_post($post_id);
        if ($post && strpos((string) $post->post_content, '[landing_page') !== false) {
            return true;
        }
        $elementor = get_post_meta($post_id, '_elementor_data', true);
        return is_string($elementor) && strpos($elementor, 'landing_page') !== false;
    }

    /**
     * The host's full-page cache (nginx in front of PHP) otherwise keeps the old
     * HTML for minutes after GitHub changed. Pages that render a landing page tell
     * that cache to keep them only briefly, so a push is visible within a minute.
     */
    public static function short_page_cache(): void
    {
        if (is_admin() || !is_singular() || headers_sent()) {
            return;
        }
        if (!self::post_uses_landing_page((int) get_queried_object_id())) {
            return;
        }
        $ttl = (int) apply_filters('olp_page_cache_seconds', self::PAGE_CACHE_SECONDS);
        header('X-Accel-Expires: ' . $ttl);
        header('Cache-Control: public, max-age=0, s-maxage=' . $ttl);
        header('X-OLP-Page: landing');
    }

    /* ---------- fetching ---------- */

    /**
     * raw.githubusercontent.com sits behind a CDN that keeps a branch URL for up
     * to five minutes. A commit SHA URL is immutable, so it is never stale. The
     * push webhook hands us the new SHA; until one is known we use the branch.
     */
    public static function git_ref(): string
    {
        $s   = self::settings();
        $ref = (string) get_option(self::REF_OPTION, '');
        return preg_match('/^[0-9a-f]{7,40}$/', $ref) ? $ref : $s['branch'];
    }

    public static function raw_url(string $name, string $file = 'index.html'): string
    {
        $s = self::settings();
        return sprintf(
            'https://raw.githubusercontent.com/%s/%s/pages/%s/%s',
            trim($s['repo'], '/'),
            rawurlencode(self::git_ref()),
            rawurlencode($name),
            $file
        );
    }

    /** Ask GitHub for the branch head. Used by the manual purge button, when no
     *  webhook payload told us the SHA. Unauthenticated calls are rate-limited
     *  to 60/hour, which a button click never approaches. */
    public static function resolve_head_sha(): string
    {
        $s    = self::settings();
        $args = ['timeout' => 8, 'headers' => ['Accept' => 'application/vnd.github+json', 'User-Agent' => 'orca-landing-pages/' . self::VERSION]];
        if (!empty($s['token'])) {
            $args['headers']['Authorization'] = 'token ' . $s['token'];
        }
        $res = wp_remote_get(sprintf('https://api.github.com/repos/%s/commits/%s', trim($s['repo'], '/'), rawurlencode($s['branch'])), $args);
        if (is_wp_error($res) || (int) wp_remote_retrieve_response_code($res) !== 200) {
            return '';
        }
        $data = json_decode((string) wp_remote_retrieve_body($res), true);
        $sha  = is_array($data) ? (string) ($data['sha'] ?? '') : '';
        return preg_match('/^[0-9a-f]{7,40}$/', $sha) ? $sha : '';
    }

    public static function generation(): int
    {
        return (int) get_option(self::GEN_OPTION, 1);
    }

    private static function cache_key(string $prefix, string $name): string
    {
        $s   = self::settings();
        $gen = $prefix === self::CACHE_PFX ? self::generation() : 0;
        return $prefix . md5($s['repo'] . '|' . $s['branch'] . '|' . self::git_ref() . '|' . $name . '|' . $gen);
    }

    /**
     * Returns [html, source] where source is one of: cache | github | stale | error.
     */
    public static function get_page(string $name, bool $force = false): array
    {
        $key = self::cache_key(self::CACHE_PFX, $name);
        if (!$force) {
            $cached = get_transient($key);
            if (is_string($cached) && $cached !== '') {
                return [$cached, 'cache'];
            }
        }

        $s    = self::settings();
        $args = [
            'timeout' => 12,
            'headers' => [
                'Cache-Control' => 'no-cache',
                'User-Agent'    => 'orca-landing-pages/' . self::VERSION,
            ],
        ];
        if (!empty($s['token'])) {
            $args['headers']['Authorization'] = 'token ' . $s['token'];
        }

        $res  = wp_remote_get(self::raw_url($name), $args);
        $code = is_wp_error($res) ? 0 : (int) wp_remote_retrieve_response_code($res);
        $body = is_wp_error($res) ? '' : (string) wp_remote_retrieve_body($res);

        if ($code === 200 && $body !== '') {
            $html = self::prepare($body, $name);
            set_transient($key, $html, $s['ttl']);
            update_option(self::cache_key(self::STALE_PFX, $name), $html, false);
            return [$html, 'github'];
        }

        $stale = get_option(self::cache_key(self::STALE_PFX, $name), '');
        if (is_string($stale) && $stale !== '') {
            set_transient($key, $stale, 60);
            return [$stale, 'stale'];
        }

        $reason = is_wp_error($res) ? $res->get_error_message() : ('HTTP ' . $code);
        return ['', 'error:' . $reason];
    }

    /**
     * Turn a full HTML document into an embeddable fragment:
     * keep <style>, stylesheet <link>s, and body content; drop <html>/<head>/<meta>/<title>.
     * Rewrite relative asset paths to the GitHub raw folder of the page.
     */
    public static function prepare(string $html, string $name): string
    {
        $out = $html;

        if (preg_match('/<body[^>]*>(.*)<\/body>/is', $html, $m)) {
            $head_parts = '';
            if (preg_match('/<head[^>]*>(.*)<\/head>/is', $html, $h)) {
                if (preg_match_all('/<style\b[^>]*>.*?<\/style>/is', $h[1], $styles)) {
                    $head_parts .= implode("\n", $styles[0]) . "\n";
                }
                if (preg_match_all('/<link\b[^>]*>/i', $h[1], $links)) {
                    foreach ($links[0] as $link) {
                        if (preg_match('/rel=["\'](stylesheet|preconnect|preload)["\']/i', $link)) {
                            $head_parts .= $link . "\n";
                        }
                    }
                }
                if (preg_match_all('/<script\b[^>]*>.*?<\/script>/is', $h[1], $scripts)) {
                    $head_parts .= implode("\n", $scripts[0]) . "\n";
                }
            }
            $out = $head_parts . $m[1];
        }

        $base = dirname(self::raw_url($name)) . '/';
        $out  = preg_replace_callback(
            '/\b(src|href)=(["\'])(?!https?:|\/\/|data:|#|mailto:|tel:|javascript:|\/)([^"\']+)\2/i',
            static function ($mm) use ($base) {
                $path = preg_replace('#^\./#', '', $mm[3]);
                return $mm[1] . '=' . $mm[2] . $base . $path . $mm[2];
            },
            $out
        );

        return trim($out);
    }

    /* ---------- shortcode ---------- */

    public static function shortcode($atts): string
    {
        $atts = shortcode_atts(['name' => ''], $atts, 'landing_page');
        $name = strtolower(preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $atts['name']));

        if ($name === '') {
            return '<!-- landing_page: no name specified -->';
        }

        $force = isset($_GET['olp_refresh']) && current_user_can('edit_pages');
        [$html, $source] = self::get_page($name, $force);

        if ($html === '') {
            $msg = '<!-- landing_page "' . esc_html($name) . '": ' . esc_html($source) . ' -->';
            if (current_user_can('edit_pages')) {
                $msg .= '<div dir="rtl" style="padding:24px;border:2px dashed #c00;color:#c00;font-family:sans-serif">'
                    . 'דף הנחיתה <b>' . esc_html($name) . '</b> לא נמצא בגיטהאב (' . esc_html($source) . '). '
                    . 'ההודעה הזו מוצגת רק למנהלים.</div>';
            }
            return $msg;
        }

        return '<div class="olp-page" data-olp-page="' . esc_attr($name) . '" data-olp-source="' . esc_attr($source) . '" data-olp-ref="' . esc_attr(substr(self::git_ref(), 0, 7)) . '">'
            . self::render_forms($html) . '</div>';
    }

    /* ---------- cache purge ---------- */

    /**
     * Invalidate every cached page by moving to a new cache generation. Old
     * transients simply stop being read and expire on their own. This works
     * whether transients live in the options table or in a persistent object
     * cache (Redis / Memcached), where a SQL LIKE over wp_options finds nothing.
     * Returns the new generation number.
     */
    /** @var string[] failures of the current purge_all() run */
    public static $step_errors = [];

    public static function step(string $name, callable $fn)
    {
        try {
            return $fn();
        } catch (\Throwable $e) {
            self::$step_errors[] = $name . ': ' . get_class($e) . ' ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine();
            return null;
        }
    }

    public static function purge_all(string $sha = ''): int
    {
        if ($sha === '') {
            $sha = self::resolve_head_sha();
        }
        if (preg_match('/^[0-9a-f]{7,40}$/', $sha)) {
            update_option(self::REF_OPTION, $sha, false);
            wp_cache_delete(self::REF_OPTION, 'options');
        }
        $next = self::generation() + 1;
        update_option(self::GEN_OPTION, $next, false);
        wp_cache_delete(self::GEN_OPTION, 'options');

        // Each step on its own (03/10/2026): from 26/09 every push hook answered 500 and nothing after the crash
        // ran (page sync, footer, self-update), with no trace of which step broke. A failing step is now recorded
        // in olp_last_errors (shown on the settings screen and in the hook's reply) and the rest still run.
        self::$step_errors = [];
        self::step('touch_landing_pages', [__CLASS__, 'touch_landing_pages']);
        self::step('cpanel_clear_cache', [__CLASS__, 'cpanel_clear_cache']);
        self::step('sync_pages', [__CLASS__, 'sync_pages']);
        self::step('sync_footer', [__CLASS__, 'sync_footer']);
        self::step('sync_conversions', [__CLASS__, 'sync_conversions']);
        self::step('sync_privacy_link', [__CLASS__, 'sync_privacy_link']);
        self::step('sync_blog', [__CLASS__, 'sync_blog']);
        update_option('olp_last_errors', self::$step_errors ? gmdate('c') . ' ' . implode(' | ', self::$step_errors) : '', false);

        // Best effort cleanup of DB-stored transients from earlier generations.
        global $wpdb;
        $like = $wpdb->esc_like('_transient_' . self::CACHE_PFX) . '%';
        $rows = $wpdb->get_col($wpdb->prepare("SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $like));
        foreach ($rows as $row) {
            delete_transient(substr($row, strlen('_transient_')));
        }
        return $next;
    }

    public static function handle_purge(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('forbidden');
        }
        check_admin_referer('olp_purge');
        $gen = self::purge_all();
        wp_safe_redirect(add_query_arg(['page' => 'orca-landing-pages', 'purged' => $gen], admin_url('options-general.php')));
        exit;
    }

    public static function rest_routes(): void
    {
        register_rest_route('olp/v1', '/page', [
            'methods'             => ['GET', 'POST'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $pid  = (int) $req->get_param('page');
                $data = json_decode((string) get_post_meta($pid, '_elementor_data', true), true);
                $rows = [];
                foreach ((array) $data as $el) {
                    if (!is_array($el)) { continue; }
                    $widgets = [];
                    $w = function ($n) use (&$w, &$widgets) { if (($n['elType'] ?? '') === 'widget') { $widgets[] = (string) ($n['widgetType'] ?? '?'); } foreach ((array) ($n['elements'] ?? []) as $c) { if (is_array($c)) { $w($c); } } };
                    $w($el);
                    $vt = self::visible_text($el);
                    $rows[] = ['id' => $el['id'] ?? '?', 'type' => $el['elType'] ?? '?', 'widgets' => $widgets, 'olp_footer' => ($el['settings']['_olp_footer'] ?? '') === 'yes',
                               'visible_chars' => function_exists('mb_strlen') ? mb_strlen($vt, 'UTF-8') : strlen($vt), 'text' => function_exists('mb_substr') ? mb_substr($vt, 0, 60, 'UTF-8') : substr($vt, 0, 60)];
                }
                $backup = get_post_meta($pid, '_olp_footer_backup', true);
                return new WP_REST_Response(['ok' => true, 'page' => $pid, 'top_level' => $rows, 'backup_runs' => is_array($backup) ? count($backup) : 0,
                    'element_cache_meta' => get_post_meta($pid, '_elementor_element_cache', true) ? 'present' : 'absent'], 200);
            },
        ]);
        register_rest_route('olp/v1', '/replace', [
            'methods'             => ['POST'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $pid  = (int) $req->get_param('page');
                $find = (string) $req->get_param('find');
                $repl = (string) $req->get_param('replace');
                if ($pid <= 0 || $find === '') {
                    return new WP_REST_Response(['ok' => false, 'error' => 'page and find required'], 400);
                }
                return new WP_REST_Response(['ok' => true] + self::replace_in_page($pid, $find, $repl), 200);
            },
        ]);
        register_rest_route('olp/v1', '/restore', [
            'methods'             => ['POST'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $remove = array_values(array_filter(array_map('trim', explode(',', (string) $req->get_param('remove')))));
                if ((string) $req->get_param('page') === 'all') {
                    $report = [];
                    foreach (self::pages_missing_forms() as $pid) {
                        $report[] = self::restore_forms($pid, []);
                    }
                    return new WP_REST_Response(['ok' => true, 'restored' => $report], 200);
                }
                $pid = (int) $req->get_param('page');
                if ($pid <= 0) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'page required'], 400);
                }
                return new WP_REST_Response(['ok' => true] + self::restore_forms($pid, $remove), 200);
            },
        ]);
        register_rest_route('olp/v1', '/form-field', [
            'methods'             => ['POST'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $pid   = (int) $req->get_param('post');
                $field = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $req->get_param('field'));
                $type  = (string) $req->get_param('type');
                $rq    = $req->get_param('required');
                $rq    = $rq === null || $rq === '' ? null : in_array((string) $rq, ['1', 'true', 'yes'], true);
                if ($pid <= 0 || $field === '' || ($type === '' && $rq === null) || ($type !== '' && !in_array($type, ['text', 'tel', 'email', 'textarea', 'number', 'checkbox', 'acceptance'], true))) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'post, field and a valid type or a required flag needed'], 400);
                }
                return new WP_REST_Response(['ok' => true] + self::set_form_field_type($pid, $field, $type, $rq), 200);
            },
        ]);
        register_rest_route('olp/v1', '/form-actions', [
            'methods'             => ['POST'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $allowed = ['save-to-database', 'email', 'email2', 'redirect', 'webhook'];
                $list = static function ($v) use ($allowed) { return array_values(array_intersect(array_filter(array_map('trim', explode(',', (string) $v))), $allowed)); };
                $pid     = (int) $req->get_param('post');
                $webhook = (string) $req->get_param('webhook');
                if ($webhook !== '' && !preg_match('#^https://(hooks\.zapier\.com/hooks/catch/[0-9]+/[a-z0-9]+|hook\.[a-z0-9-]+\.make\.com/[a-z0-9]+)/?$#i', $webhook)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'webhook must be a Zapier catch hook or a Make webhook'], 400);
                }
                if ($pid <= 0) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'post required'], 400);
                }
                $adv = $req->get_param('advanced');
                $adv = $adv === null || $adv === '' ? null : in_array((string) $adv, ['1', 'true', 'yes'], true);
                $redirect = esc_url_raw((string) $req->get_param('redirect'));
                if ($redirect !== '' && !preg_match('#^https://#', $redirect)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'redirect must be an https url'], 400);
                }
                $meta = $req->get_param('metadata');
                $meta = $meta === null ? null : array_values(array_intersect(array_filter(array_map('trim', explode(',', (string) $meta))), ['date', 'time', 'page_url', 'user_agent', 'remote_ip', 'credit']));
                return new WP_REST_Response(['ok' => true] + self::set_form_actions($pid, $list($req->get_param('remove')), $list($req->get_param('add')), $webhook, $adv, $meta, sanitize_text_field((string) $req->get_param('form_name')), $redirect), 200);
            },
        ]);
        register_rest_route('olp/v1', '/form-info', [
            'methods'             => ['GET'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                // read-only: what a form does after submit, and Elementor's own log of the last submissions
                $pid  = (int) $req->get_param('post');
                $data = json_decode((string) get_post_meta($pid, '_elementor_data', true), true);
                $forms = [];
                $walk = function ($els) use (&$walk, &$forms) {
                    foreach ((array) $els as $el) {
                        if (!is_array($el)) { continue; }
                        if (($el['widgetType'] ?? '') === 'form') {
                            $st = (array) ($el['settings'] ?? []);
                            $keep = [];
                            foreach ($st as $k => $v) {
                                if (preg_match('/^(submit_actions|webhooks|webhooks_advanced_data|email_to|email_subject|email_from|redirect_to|form_name|mailchimp|activecampaign|getresponse|convertkit|mailerlite|drip|slack|discord|custom_messages|error_message|server_message)/', (string) $k)) { $keep[$k] = $v; }
                            }
                            $keep['fields'] = array_map(static function ($f) { return ($f['custom_id'] ?? '?') . ':' . ($f['field_type'] ?? 'text') . (!empty($f['required']) ? '*' : ''); }, (array) ($st['form_fields'] ?? []));
                            $forms[] = ['id' => $el['id'] ?? '?', 'settings' => $keep];
                        }
                        $walk($el['elements'] ?? []);
                    }
                };
                $walk($data);
                global $wpdb;
                $log = [];
                $t1 = $wpdb->prefix . 'e_submissions'; $t2 = $wpdb->prefix . 'e_submissions_actions_log';
                if ($wpdb->get_var("SHOW TABLES LIKE '$t2'") === $t2) {
                    $log = $wpdb->get_results("SELECT s.id, s.created_at_gmt, s.post_id, s.element_id, s.status, a.action_name, a.status AS action_status, a.log FROM $t1 s LEFT JOIN $t2 a ON a.submission_id = s.id ORDER BY s.id DESC LIMIT 12", ARRAY_A);
                }
                return new WP_REST_Response(['ok' => true, 'post' => $pid, 'forms' => $forms, 'recent_submissions' => $log], 200);
            },
        ]);
        register_rest_route('olp/v1', '/unconvert', [
            'methods'             => ['POST'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $pid = (int) $req->get_param('page');
                if ($pid <= 0) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'page required'], 400);
                }
                return new WP_REST_Response(['ok' => true] + self::unconvert_page($pid), 200);
            },
        ]);
        register_rest_route('olp/v1', '/refresh', [
            'methods'             => ['POST', 'GET'],
            'permission_callback' => '__return_true',
            'callback'            => static function (WP_REST_Request $req) {
                $s      = self::settings();
                $secret = (string) $s['webhook_secret'];
                $given  = (string) ($req->get_header('x-olp-secret') ?: $req->get_param('secret'));
                if ($secret === '' || !hash_equals($secret, $given)) {
                    return new WP_REST_Response(['ok' => false, 'error' => 'bad secret'], 403);
                }
                $payload = $req->get_json_params();
                $sha     = is_array($payload) ? (string) ($payload['after'] ?? '') : '';
                $gen     = self::purge_all($sha);
                $update = (string) self::step('self_update', [__CLASS__, 'self_update']);
                if (self::$step_errors) {
                    update_option('olp_last_errors', gmdate('c') . ' ' . implode(' | ', self::$step_errors), false);
                }
                $caches = [];
                foreach (self::landing_page_ids() as $pid) {
                    $caches = array_unique(array_merge($caches, self::purge_page_cache_plugins($pid)));
                }
                return new WP_REST_Response(['ok' => true, 'generation' => $gen, 'ref' => self::git_ref(), 'touched' => self::landing_page_ids(), 'page_cache_plugins' => array_values($caches), 'cpanel' => (string) get_option('olp_last_cpanel_purge', 'not configured'), 'pages' => (string) get_option('olp_last_sync', ''), 'footer' => (string) get_option('olp_last_footer', ''), 'convert' => (string) get_option('olp_last_convert', ''), 'plugin' => self::VERSION . ' — ' . $update, 'errors' => self::$step_errors], 200);
            },
        ]);
    }

    /* ---------- admin ---------- */

    public static function admin_menu(): void
    {
        add_options_page('דפי נחיתה (GitHub)', 'דפי נחיתה (GitHub)', 'manage_options', 'orca-landing-pages', [__CLASS__, 'settings_page']);
    }

    public static function register_settings(): void
    {
        register_setting('olp', self::OPTION, [
            'type'              => 'array',
            'sanitize_callback' => static function ($in) {
                $d = self::defaults();
                return [
                    'repo'           => sanitize_text_field($in['repo'] ?? $d['repo']),
                    'branch'         => sanitize_text_field($in['branch'] ?? $d['branch']),
                    'token'          => trim((string) ($in['token'] ?? '')),
                    'ttl'            => max(30, (int) ($in['ttl'] ?? $d['ttl'])),
                    'webhook_secret' => trim((string) ($in['webhook_secret'] ?? '')),
                    'cpanel_host'    => trim((string) ($in['cpanel_host'] ?? '')),
                    'cpanel_user'    => trim((string) ($in['cpanel_user'] ?? '')),
                    'cpanel_token'   => trim((string) ($in['cpanel_token'] ?? '')),
                ];
            },
        ]);
    }

    public static function settings_page(): void
    {
        $s = self::settings();
        $purged = isset($_GET['purged']) ? (int) $_GET['purged'] : null;
        ?>
        <div class="wrap" dir="rtl">
            <h1>דפי נחיתה מגיטהאב</h1>
            <?php if ($purged !== null): ?>
                <div class="notice notice-success"><p>הזיכרון נוקה (דור <?php echo $purged; ?>). הטעינה הבאה תמשוך מגיטהאב.</p></div>
            <?php endif; ?>
            <p>גרסה בשימוש מגיטהאב: <code dir="ltr"><?php echo esc_html(self::git_ref()); ?></code><br>עמודים מהריפו (pages.json): <code dir="ltr"><?php echo esc_html((string) get_option('olp_last_sync', 'עדיין לא')); ?></code><br>פוטר מהריפו (sites.json): <code dir="ltr"><?php echo esc_html((string) get_option('olp_last_footer', 'עדיין לא')); ?></code><br>המרת עמודים קיימים (sites.json): <code dir="ltr"><?php echo esc_html((string) get_option('olp_last_convert', 'עדיין לא')); ?></code><br>תקלות בעדכון האחרון: <code dir="ltr"><?php echo esc_html((string) get_option('olp_last_errors', '') ?: 'אין'); ?></code><br>עדכון עצמי אחרון של התוסף: <code dir="ltr"><?php echo esc_html((string) get_option('olp_last_self_update', 'עדיין לא')); ?></code></p>
            <p>בעמוד באלמנטור מוסיפים ווידג'ט Shortcode עם הקוד <code>[landing_page name="שם-התיקייה"]</code>.
               הדף נמשך מ-<code>pages/&lt;שם&gt;/index.html</code> בריפו ונשמר בזיכרון למשך <?php echo (int) $s['ttl']; ?> שניות.
               כדי לראות שינוי מיד: להוסיף <code>?olp_refresh=1</code> לכתובת הדף (כמנהל מחובר), או ללחוץ על הכפתור למטה.</p>

            <form method="post" action="options.php">
                <?php settings_fields('olp'); ?>
                <table class="form-table">
                    <tr><th>ריפו (owner/name)</th><td><input type="text" class="regular-text" dir="ltr" name="<?php echo self::OPTION; ?>[repo]" value="<?php echo esc_attr($s['repo']); ?>"></td></tr>
                    <tr><th>ענף</th><td><input type="text" dir="ltr" name="<?php echo self::OPTION; ?>[branch]" value="<?php echo esc_attr($s['branch']); ?>"></td></tr>
                    <tr><th>טוקן GitHub (רק אם הריפו פרטי)</th><td><input type="password" class="regular-text" dir="ltr" name="<?php echo self::OPTION; ?>[token]" value="<?php echo esc_attr(defined('OLP_GITHUB_TOKEN') ? '' : $s['token']); ?>" autocomplete="new-password">
                        <?php if (defined('OLP_GITHUB_TOKEN')): ?><p class="description">מוגדר ב-wp-config.php</p><?php endif; ?></td></tr>
                    <tr><th>זמן שמירה בזיכרון (שניות)</th><td><input type="number" min="30" name="<?php echo self::OPTION; ?>[ttl]" value="<?php echo (int) $s['ttl']; ?>"></td></tr>
                    <tr><th>סוד ל-webhook (אופציונלי)</th><td><input type="text" class="regular-text" dir="ltr" name="<?php echo self::OPTION; ?>[webhook_secret]" value="<?php echo esc_attr($s['webhook_secret']); ?>">
                        <p class="description">אם מוגדר: <code dir="ltr"><?php echo esc_url(rest_url('olp/v1/refresh')); ?>?secret=…</code> מנקה את הזיכרון. אפשר לחבר כ-webhook בגיטהאב כדי שכל push יתעדכן מיד.</p></td></tr>
                    <tr><th colspan="2"><h2 style="margin:18px 0 4px">ניקוי זיכרון השרת (cPanel)</h2>
                        <p class="description" style="font-weight:normal">FastCloud שומר את העמוד המוכן עד שמנקים אותו. עם טוקן API של cPanel התוסף מנקה אותו בכל push. יצירת טוקן: cPanel → Manage API Tokens → Create. מספיק טוקן ללא הרשאות מיוחדות.</p></th></tr>
                    <tr><th>כתובת cPanel</th><td><input type="text" class="regular-text" dir="ltr" name="<?php echo self::OPTION; ?>[cpanel_host]" value="<?php echo esc_attr($s['cpanel_host']); ?>" placeholder="fast208.fcsrv.com:2083"></td></tr>
                    <tr><th>שם משתמש cPanel</th><td><input type="text" class="regular-text" dir="ltr" name="<?php echo self::OPTION; ?>[cpanel_user]" value="<?php echo esc_attr($s['cpanel_user']); ?>"></td></tr>
                    <tr><th>טוקן API של cPanel</th><td><input type="password" class="regular-text" dir="ltr" name="<?php echo self::OPTION; ?>[cpanel_token]" value="<?php echo esc_attr($s['cpanel_token']); ?>" autocomplete="new-password">
                        <p class="description">ניקוי אחרון: <code dir="ltr"><?php echo esc_html((string) get_option('olp_last_cpanel_purge', 'עדיין לא')); ?></code></p></td></tr>
                </table>
                <?php submit_button('שמירה'); ?>
            </form>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="olp_purge">
                <?php wp_nonce_field('olp_purge'); ?>
                <?php submit_button('נקה זיכרון ומשוך מחדש מגיטהאב', 'secondary'); ?>
            </form>
        </div>
        <?php
    }
}

Orca_Landing_Pages::boot();
